function LoginPage() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Iniciar Sesión</h1>
      <p>Accede con tu usuario y contraseña.</p>
    </div>
  );
}

export default LoginPage;
